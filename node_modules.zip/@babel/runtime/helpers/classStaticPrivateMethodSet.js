function _classStaticPrivateMethodSet() {
  throw new TypeError("attempted to set read only static private field");
}

module.exports = _classStaticPrivateMethodSet;